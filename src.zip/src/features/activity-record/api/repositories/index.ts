export type { RecordRepository } from './RecordRepository.interface';
export { RecordRepositoryImpl } from './RecordRepositoryImpl';
