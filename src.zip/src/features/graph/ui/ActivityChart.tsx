import { useState } from 'react';
import { Stack, Text, Group, ActionIcon } from '@mantine/core';
import { IconChartBar, IconChartLine } from '@tabler/icons-react';
import { ChartTypeEnum } from '@/shared/types';
import type { ChartDataPoint, ChartType } from '@/shared/types';
import type { ContainerSize } from '@/features/grid-layout';
import { ChartFactory } from './ChartFactory';
import './ActivityChart.css';

interface ActivityChartProps {
  title: string;
  data: ChartDataPoint[];
  dataLabel: string;
  color?: string;
  height?: number;
  chartType?: ChartType;
  /** コンテナサイズ（動的スタイリング用） */
  containerSize?: ContainerSize;
}

/**
 * アクティビティチャートコンポーネント
 * タイトルとグラフを表示する統合コンポーネント
 * ユーザーがグラフタイプを切り替え可能
 * コンテナサイズに応じて動的にスタイルを調整
 */
export function ActivityChart({
  title,
  data,
  dataLabel,
  color = 'blue.6',
  height = 200,
  chartType: initialChartType = ChartTypeEnum.BAR,
  containerSize,
}: ActivityChartProps) {
  // グラフタイプの状態管理
  const [currentChartType, setCurrentChartType] = useState<ChartType>(initialChartType);

  // グラフタイプ切り替えハンドラー（イベント伝播を停止）
  const handleChartTypeChange = (type: ChartType) => (e: React.MouseEvent) => {
    e.stopPropagation(); // 親要素へのイベント伝播を停止
    e.preventDefault(); // デフォルト動作を防止
    setCurrentChartType(type);
  };
  
  // コンテナサイズに応じた動的スタイル
  const getDynamicStyles = () => {
    if (!containerSize) return {};
    
    const { category } = containerSize;
    
    // 極小サイズ（~200px）
    if (category === 'xs') {
      return {
        titleSize: '0.75rem',
        titleWeight: 600,
        gap: '0.25rem',
        padding: '0.25rem',
        iconSize: 12,
        buttonSize: 24,
        showControls: false, // 極小サイズではボタン非表示
      };
    }
    
    // 小サイズ（~300px）
    if (category === 'sm') {
      return {
        titleSize: '0.875rem',
        titleWeight: 600,
        gap: '0.5rem',
        padding: '0.5rem',
        iconSize: 14,
        buttonSize: 28,
        showControls: true,
      };
    }
    
    // 中サイズ（~400px）
    if (category === 'md') {
      return {
        titleSize: '1rem',
        titleWeight: 600,
        gap: '0.75rem',
        padding: '0.75rem',
        iconSize: 16,
        buttonSize: 32,
        showControls: true,
      };
    }
    
    // 大サイズ（~600px）
    if (category === 'lg') {
      return {
        titleSize: '1.125rem',
        titleWeight: 700,
        gap: '1rem',
        padding: '1rem',
        iconSize: 18,
        buttonSize: 36,
        showControls: true,
      };
    }
    
    // 特大サイズ（600px~）
    return {
      titleSize: '1.25rem',
      titleWeight: 700,
      gap: '1rem',
      padding: '1rem',
      iconSize: 20,
      buttonSize: 40,
      showControls: true,
    };
  };
  
  const styles = getDynamicStyles();

  return (
    <Stack 
      gap={styles.gap || 'sm'}
      className="activity-chart-container"
      style={{ 
        height: '100%', 
        overflow: 'hidden',
        padding: styles.padding,
        transition: 'all 0.3s ease', // スムーズなトランジション
      }}
    >
      <Group 
        justify="space-between" 
        align="center" 
        px={styles.padding || 'md'}
        className="activity-chart-header"
      >
        <Text 
          fw={styles.titleWeight || 600}
          className="activity-chart-title"
          style={{
            fontSize: styles.titleSize || '1rem',
            transition: 'font-size 0.3s ease',
          }}
        >
          {title}
        </Text>
        
        {/* グラフタイプ切り替えボタン（コンテナが小さい場合は非表示） */}
        {(styles.showControls ?? true) && (
          <Group 
            gap="xs"
            className="activity-chart-controls"
          >
            <ActionIcon
              variant={currentChartType === ChartTypeEnum.BAR ? 'filled' : 'subtle'}
              color="blue"
              size="sm"
              onClick={handleChartTypeChange(ChartTypeEnum.BAR)}
              title="棒グラフで表示"
              className="activity-chart-button"
              style={{
                width: styles.buttonSize,
                height: styles.buttonSize,
                minWidth: styles.buttonSize,
                minHeight: styles.buttonSize,
                transition: 'all 0.3s ease',
              }}
            >
              <IconChartBar size={styles.iconSize || 16} className="activity-chart-icon" />
            </ActionIcon>
            <ActionIcon
              variant={currentChartType === ChartTypeEnum.LINE ? 'filled' : 'subtle'}
              color="teal"
              size="sm"
              onClick={handleChartTypeChange(ChartTypeEnum.LINE)}
              title="折れ線グラフで表示"
              className="activity-chart-button"
              style={{
                width: styles.buttonSize,
                height: styles.buttonSize,
                minWidth: styles.buttonSize,
                minHeight: styles.buttonSize,
                transition: 'all 0.3s ease',
              }}
            >
              <IconChartLine size={styles.iconSize || 16} className="activity-chart-icon" />
            </ActionIcon>
          </Group>
        )}
      </Group>

      <div style={{ flex: 1, minHeight: 0, overflow: 'hidden' }}>
        <ChartFactory
          data={data}
          dataLabel={dataLabel}
          color={color}
          height={height}
          chartType={currentChartType}
        />
      </div>
    </Stack>
  );
}
