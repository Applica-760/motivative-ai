/**
 * AI Character Hooks
 */
export { useEyeTracking } from './useEyeTracking';
export { useParallax } from './useParallax';
export { useEncouragement } from './useEncouragement';
