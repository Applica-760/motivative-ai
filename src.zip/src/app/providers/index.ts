/**
 * app/providers のエクスポート
 * Feature-Sliced Design: app layer
 */

export { AppProviders } from './AppProviders';
