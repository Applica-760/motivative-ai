/**
 * StyledModal - 統一されたモーダルコンポーネント
 */
export { StyledModal, type StyledModalProps } from './StyledModal';
