export { AboutModal } from './AboutModal';
export type { AboutModalProps } from './AboutModal';
